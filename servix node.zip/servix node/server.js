require('dotenv').config();
const express = require('express');
const db = require('./db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const authMiddleware = require('./authmiddleware');
const { chatWithAgent, transcribeAudio } = require('./AI/agent');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const app = express();
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, path.join(__dirname, 'uploads/'));
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });
const PORT = 3002;
const JWT_SECRET = process.env.JWT_SECRET;

app.use(express.json());
// Log every request
app.use((req, res, next) => {
    console.log('REQUEST:', req.method, req.url);
    next();
});



// Test routes
app.get('/test', (req, res) => {
    res.send('TEST WORKS');
});

app.post('/test', (req, res) => {
    res.send('Test route working!');
});


// Home route
app.get('/', (req, res) => {
    res.send('Servix API is Running!');
});

app.get('/login-test', (req, res) => {
    res.send('LOGIN ROUTE TEST WORKS');
});

// Test database tables
app.get('/tables', async (req, res) => {
    try {
        const [tables] = await db.query('SHOW TABLES');
        res.json(tables);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get all users (protected)
app.get('/users', authMiddleware, async (req, res) => {
    try {
        const [users] = await db.query(`
            SELECT user_id, first_name, last_name, email, phone
            FROM Users
        `);
        res.json(users);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get current logged-in user (protected)
app.get('/me', authMiddleware, async (req, res) => {
    try {
        const [users] = await db.query(
            'SELECT user_id, first_name, last_name, email, phone FROM Users WHERE user_id = ?',
            [req.user.user_id]
        );

        if (users.length === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json(users[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Register new user
app.post('/register', async (req, res) => {
    try {
        const { first_name, last_name, email, phone, password } = req.body;

        if (!first_name || !last_name || !email || !password) {
            return res.status(400).json({
                message: 'Please enter all required fields'
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        await db.query(
            `INSERT INTO Users
            (first_name, last_name, email, phone, password_hash)
            VALUES (?, ?, ?, ?, ?)`,
            [first_name, last_name, email, phone || null, hashedPassword]
        );

        res.status(201).json({
            message: 'User registered successfully!'
        });
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({
                message: 'Email already exists'
            });
        }

        res.status(500).json({ error: error.message });
    }
});

// Login API
app.post('/login', async (req, res) => {
    try {
        console.log('LOGIN ROUTE REACHED');
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                message: 'Email and password are required'
            });
        }

        const [users] = await db.query(
            'SELECT * FROM Users WHERE email = ?',
            [email]
        );

        if (users.length === 0) {
            return res.status(401).json({
                message: 'Invalid email or password'
            });
        }

        const user = users[0];

        const isMatch = await bcrypt.compare(password, user.password_hash);

        if (!isMatch) {
            return res.status(401).json({
                message: 'Invalid email or password'
            });
        }

        const token = jwt.sign(
            { user_id: user.user_id, email: user.email },
            JWT_SECRET,
            { expiresIn: '1h' }
        );

        console.log('TOKEN CREATED:', token);
        res.json({
            message: 'Login successful!',
            token: token,
            user: {
                user_id: user.user_id,
                first_name: user.first_name,
                last_name: user.last_name,
                email: user.email
            }
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
//  categories (protected)
app.get('/categories', authMiddleware, async (req, res) => {
    try {
        const [categories] = await db.query(
            'SELECT category_id, category_name, description FROM service_category'
        );

        res.status(200).json(categories);

    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: 'Error fetching categories',
            error: error.message
        });
    }
});
//  Service Providers
app.get('/service_providers', async (req, res) => {
    try {
        const [providers] = await db.query(
            'SELECT * FROM service_providers'
        );

        res.json(providers);

    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: 'Error fetching service providers',
            error: error.message
        });
    }
});
//  Service Requests
app.get('/service_requests', async (req, res) => {
    try {
        const [requests] = await db.query(
            'SELECT * FROM service_requests'
        );

        res.json(requests);

    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: 'Error fetching service requests',
            error: error.message
        });
    }
});
//  Appointments
app.get('/appointments', async (req, res) => {
    try {
        const [appointments] = await db.query(
            'SELECT * FROM appointments'
        );

        res.json(appointments);

    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: 'Error fetching appointments',
            error: error.message
        });
    }
});
//  Location
app.get('/location', async (req, res) => {
    try {
        const [location] = await db.query(
            'SELECT * FROM location'
        );

        res.json(location);

    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: 'Error fetching location',
            error: error.message
        });
    }
});
//  notification
app.get('/notification', async (req, res) => {
    try {
        const [notification] = await db.query(
            'SELECT * FROM notification'
        );

        res.status(200).json(notification);

    } catch (error) {
        console.error( error);
        res.status(500).json({
            message: 'Error fetching notification',
            error: error.message
        });
    }
});
//  payment
app.get('/payment', async (req, res) => {
    try {
        const [payment] = await db.query(
            'SELECT * FROM payment'
        );

        res.status(200).json(payment);

    } catch (error) {
        console.error( error);

        res.status(500).json({
            message: 'Error fetching payment',
            error: error.message
        });
    }
});
//  provider category
app.get('/provider_category', async (req, res) => {
    try {
        const [provider_category] = await db.query(
            'SELECT * FROM provider_category'
        );

        res.status(200).json(provider_category);

    } catch (error) {
        console.error('Provider Category Error:', error);

        res.status(500).json({
            message: 'Error fetching provider_category',
            error: error.message
        });
    }
});
//  reviews
app.get('/reviews', async (req, res) => {
    try {
        const [result] = await db.query(
            'SELECT * FROM reviews'
        );

        res.status(200).json(result);

    } catch (error) {
        console.error('Reviews Error:', error);

        res.status(500).json({
            message: 'Error fetching reviews',
            error: error.message
        });
    }
});
//  admin
app.get('/admin', async (req, res) => {
    try {
        const [admin] = await db.query(
            'SELECT admin_id, name, email FROM admin'
        );

        res.status(200).json(admin);

    } catch (error) {
        console.error( error);

        res.status(500).json({
            message: 'Error fetching admin',
            error: error.message
        });
    }
});
// Servix AI Assistant
app.post('/ai/chat', async (req, res) => {
    try {
        const { message } = req.body;

        if (!message) {
            return res.status(400).json({
                message: 'Please enter a message'
            });
        }

        const reply = await chatWithAgent(message);

        res.status(200).json({
            success: true,
            reply: reply
        });

    } catch (error) {
        console.error('AI Error:', error);

        res.status(500).json({
            success: false,
            message: 'AI Assistant error'
        });
    }
});
app.post('/ai/upload-audio', upload.single('audio'), (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'Please upload an audio file'
            });
        }

        res.status(200).json({
            success: true,
            message: 'Audio uploaded successfully',
            filename: req.file.filename
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Audio upload failed'
        });
    }
});
app.post('/ai/transcribe', upload.single('audio'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'Please upload an audio file'
            });
        }

        const text = await transcribeAudio(req.file.path);

        res.status(200).json({
            success: true,
            message: 'Audio transcribed successfully',
            transcription: text
        });

    } catch (error) {
        console.error('Transcription Error:', error);

        res.status(500).json({
            success: false,
            message: 'Audio transcription failed'
        });
    }
});
app.post('/ai/voice-chat', upload.single('audio'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'Please upload an audio file'
            });
        }

        // Convert audio to text
        const transcription = await transcribeAudio(req.file.path);

        // Send the text to Servix AI
        const reply = await chatWithAgent(transcription);

        res.status(200).json({
            success: true,
            message: 'Voice chat completed successfully',
            transcription: transcription,
            reply: reply
        });

    } catch (error) {
        console.error('Voice Chat Error:', error);

        res.status(500).json({
            success: false,
            message: 'Voice chat failed'
        });
    }
});
// Start server
app.listen(PORT, () => {
    console.log(`Servix API running on port ${PORT}`);
});