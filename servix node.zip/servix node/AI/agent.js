require('dotenv').config();

const { GoogleGenAI } = require('@google/genai');
const fs = require('fs');

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

async function chatWithAgent(message) {
  const response = await ai.models.generateContent({
    model: 'gemini-3.8-flash',
    contents: `
      You are Servix AI Assistant.
      You help users find services and service providers.

      If the user speaks Arabic, reply in simple Egyptian Arabic.
If the user speaks English, reply in English.
Always answer in the same language as the user.

Be friendly, clear, and helpful.
Give accurate answers about services and service providers.

      User: ${message}
    `,
  });

  return response.text;
}

module.exports = { chatWithAgent, transcribeAudio };
async function transcribeAudio(filePath) {
    const audioBuffer = fs.readFileSync(filePath);

    const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
            {
                inlineData: {
                    mimeType: 'audio/mpeg',
                    data: audioBuffer.toString('base64')
                }
            },
            {
                text: 'Convert this audio to text. Write the spoken words exactly as heard.'
            }
        ]
    });

    return response.text;
}