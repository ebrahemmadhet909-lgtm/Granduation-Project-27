const db = require('./db');

async function testConnection() {
    try {
        const [rows] = await db.query('SELECT DATABASE() AS dbName');
        console.log('Connected to database:', rows[0].dbName);
    } catch (error) {
        console.error('Connection failed:', error.message);
    } finally {
        await db.end();
    }
}

testConnection();