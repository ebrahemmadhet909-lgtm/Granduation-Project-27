const mysql = require('mysql2/promise');
require('dotenv').config();

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Ahmed2004',
    database: 'Servix',
    port: 3306
});

module.exports = db;